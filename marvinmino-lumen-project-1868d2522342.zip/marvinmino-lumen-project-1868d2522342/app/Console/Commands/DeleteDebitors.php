<?php

namespace App\Console\Commands;

use Carbon\Carbon;
use Illuminate\Console\Command;

/**
 * Class deletePostsCommand
 *
 * @category Console_Command
 * @package  App\Console\Commands
 */
class DeleteDebitors extends Command
{
    /**
     * The console command name.
     *
     * @var string
     */
    protected $signature = "remove:notpayers";

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = "Delete the users that havent paid in 24 hours after their purchuse";


    /**
     * @return void
     */
    public function handle()
    {
        $trips = Trip::with('customers')->where('due_date', '<', Carbon::now())->get();
        foreach ($trips as $trip) {
            $trip->customers
                ->where('pivot.paid', false)
                ->where('pivot.created_at', '<', Carbon::now()->subDay())
                ->delete();
        }
    }
}
