<?php

namespace App\Console\Commands;

use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use App\Models\User;

/**
 * Class deletePostsCommand
 *
 * @category Console_Command
 * @package  App\Console\Commands
 */
class ReloadUserToken extends Command
{
    /**
     * The console command name.
     *
     * @var string
     */
    protected $signature = "reload:token";

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = "Reload the verification token when users have not verified their account in 3 hours";


    /**
     * @return void
     */
    public function handle()
    {
        $users = User::where('verified', 0)
                ->where('created_at', '<', Carbon::now()->subHours(3))
                ->all();
                
        foreach ($users as $user) {
            $token = md5(rand(1, 10) . microtime());
            $user->update(array('token' => $token));
        }
    }
}
