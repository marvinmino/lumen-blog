<?php

namespace App\Exceptions;

use Exception;
use Illuminate\Http\Response;

class TripNotFoundException extends Exception
{

    /**
     * Report or log an exception.
     *
     * @return void
     */
    public function report()
    {
        \Log::debug('Trip not found');
    }


    /**
     * Render the exception into an HTTP response.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function render($request)
    {
        return response()->json('Trip Not Found', Response::HTTP_INTERNAL_SERVER_ERROR);
    }
}
