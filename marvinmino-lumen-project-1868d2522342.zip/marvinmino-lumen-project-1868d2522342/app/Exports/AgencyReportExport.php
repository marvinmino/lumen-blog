<?php

namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;

use App\Repositories\AgencyRepository;

class AgencyReportExport implements FromArray, WithHeadings, ShouldAutoSize
{
    protected $invoices;

    /**
     *
     * @param array $invoices
     */
    public function __construct(array $invoices)
    {
        $this->invoices = $invoices;
    }

    /**
     *
     * @return array
     */
    public function array(): array
    {
        $sumRating      =   0;
        $sumCustomers   =   0;
        $sumAmount      =   0;
        $counter        =   0;
        foreach ($this->invoices as $trip) {
            $sumRating      =   $sumRating    +   $trip['average_rating'];
            $sumCustomers   =   $sumCustomers +   $trip['total_customers'];
            $sumAmount      =   $sumAmount    +   $trip['total_amount'];
            $counter ++;
        }
        $this->invoices[]=[ "trip_id"           =>     '',
                            "trip_title"        =>     '',
                            "average_rating"    =>     $sumRating/$counter,
                            "total_customers"   =>     $sumCustomers,
                            "total_amount"      =>     $sumAmount,
    ];
        return $this->invoices;
    }

    /**
     *
     * @return array
     */
    public function headings(): array
    {
        return [
            'Trip ID',
            'Trip Title',
            'Average Rating',
            'Nr. Of Customers',
            'Total Amount'
        ];
    }
}
