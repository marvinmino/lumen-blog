<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Repositories\AgencyRepository;
use App\Http\Requests\AgencyStoreRequest;
use App\Models\User;
use App\Models\Agency;
use App\Models\Customer;
use App\Models\Trip;
use \Auth;
use Illuminate\Http\Response;
use App\Jobs\CommercialEmailJob;
use Carbon\Carbon;
use App\Http\Resources\AgencyResource;
use Maatwebsite\Excel\Facades\Excel;

class AgencyController extends Controller
{

    /**
     *
     * @var $agencyRepository
     */
    protected $agencyRepository;




    /**
     * @param AgencyRepository $agencyRepository
     */
    
    public function __construct(AgencyRepository $agencyRepository)
    {
        $this->agencyRepository = $agencyRepository;
    }

    /**
     * @param $agency
     * @param Request $request
     * @return void
     */
    public function show($agency, Request $request)
    {
        try {
            $agency = Agency::findOrFail($agency);
            return new AgencyResource($agency);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('Agency Not Found', Response::HTTP_NOT_FOUND);
        }
    }



    /**
     * @param $agency
     * @param Request $request
     * @return void
     */
    public function destroy($agency, Request $request)
    {
        try {
            $this->agencyRepository->destroy();
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('Agency Not Found', Response::HTTP_NOT_FOUND);
        }
        return $this->successResponse('Agency Deleted', Response::HTTP_NO_CONTENT);
    }

    /**
     * @param Request $request
     * @return void
     */
    public function store(AgencyStoreRequest $request)
    {
        try {
            $data = $this->agencyRepository->save($request->all());
            return new AgencyResource($data);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('System error', Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @param $agency
     * @param Request $request
     * @return void
     */
    public function edit($agency, AgencyStoreRequest $request)
    {
        try {
            $this->agencyRepository->update($request->all(), $agency);
            return $this->successResponse('Agency updated successfully', Response::HTTP_ACCEPTED);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('Agency Not Found', Response::HTTP_NOT_FOUND);
        }
    }


    /**
     * @param integer $trip
     * @param Request $request
     * @return void
     */
    public function sendAd($trip, Request $request)
    {
        if (!empty($request->input('customers'))) {
            return $this->errorResponse('Error', Response::HTTP_BAD_REQUEST);
        }
        dispatch(new CommercialEmailJob($trip, $request->all()));
        return $this->successResponse('Emails sent', Response::HTTP_OK);
    }

    /**
     *
     * @param Request $request
     * @return void
     */
    public function report(Request $request)
    {
        $data = $this->agencyRepository->report($request->all());
        return $this->successResponse($data, Response::HTTP_OK);
    }

    /**
     *
     * @param Request $request
     * @return void
     */
    public function downloadReport(Request $request)
    {
        $data = $this->agencyRepository->report($request->all());
        $agency = Agency::findOrFail($request->agency_id);
        $export = new \App\Exports\AgencyReportExport($data);
        return Excel::download($export, $agency->name.'.xlsx');
    }

    /**
     *
     * @return void
     */
    public function index()
    {
        $agencies = Agency::paginate(10);
        return AgencyResource::collection($agencies);
    }
}
