<?php

namespace App\Http\Controllers;

use Laravel\Lumen\Routing\Controller as BaseController;
use App\Utilities\Responser;

class Controller extends BaseController
{
    use Responser;
}
