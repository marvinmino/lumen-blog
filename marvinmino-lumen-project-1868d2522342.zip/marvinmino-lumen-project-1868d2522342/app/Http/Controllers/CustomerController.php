<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repositories\CustomerRepository;
use App\Http\Requests\CustomerStoreRequest;
use App\Models\User;
use App\Models\Agency;
use App\Models\Trip;
use App\Models\Customer;
use Illuminate\Support\Facades\DB;
use \Auth;
use Illuminate\Http\Response;
use App\Http\Resources\CustomerResource;

/**
 * Undocumented class
 */
class CustomerController extends Controller
{
    
    /**
     * @var CustomerRepository $customerRepository
     */
    private CustomerRepository $customerRepository;

    /**

     *
     * @param CustomerRepository $customerRepository
     */
    public function __construct(CustomerRepository $customerRepository)
    {
        $this->customerRepository = $customerRepository;
    }

    /**
     *
     * @param Request $request
     * @return void
     */
    public function store(CustomerStoreRequest $request)
    {
        try {
            $data = $this->customerRepository->save($request->all());
            return new CustomerResource($data);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('System Error', Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Function for user to participate on a given trip
     *
     * @param Request $request
     * @return void
     */
    public function participate(Request $request)
    {
        try {
            $customerId = Auth::user()->customer->id;
            $this->customerRepository->participate($request['trip_id'], $customerId);
            return $this->successResponse('Accepted', Response::HTTP_OK);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('System Error', Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     *
     * @param integer $customer
     * @param Request $request
     * @return void
     */
    public function show($customer, Request $request)
    {
        try {
            $customer = Customer::findOrFail($customer);
            return new CustomerResource($customer);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('Customer Not Found', Response::HTTP_NOT_FOUND);
        }
    }

    /**
     *
     * @param $customer
     * @param Request $request
     * @return void
     */
    public function destroy($customer, Request $request)
    {
        try {
            $this->customerRepository->delete($customer);
            return $this->successResponse('Customer Deleted', Response::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('Customer Not Found', Response::HTTP_NOT_FOUND);
        }
    }

    /**
     *
     * @param $customer
     * @param Request $request
     * @return void
     */
    public function update($customer, Request $request)
    {
        try {
            $this->customerRepository->update($request->all(), $customer);
            return $this->successResponse('Customer updated successfully', Response::HTTP_ACCEPTED);
        } catch (\Exception $e) {
            \Log::error($e);
        }
        return $this->errorResponse('Customer Not Found', Response::HTTP_NOT_FOUND);
    }

    /**
     *
     * @return void
     */
    public function index()
    {
        $customers = Customer::paginate(10);
        return CustomerResource::collection($customers);
    }
}
