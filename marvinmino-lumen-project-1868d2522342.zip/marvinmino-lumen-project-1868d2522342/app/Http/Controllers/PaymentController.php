<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PayPal\Api\Amount;
use PayPal\Api\Details;
use PayPal\Api\Item;
use App\Traits\Responser;
/** All Paypal Details class **/
use PayPal\Api\ItemList;
use PayPal\Api\Payer;
use PayPal\Api\Payment;
use PayPal\Api\PaymentExecution;
use PayPal\Api\RedirectUrls;
use PayPal\Api\Transaction;
use PayPal\Auth\OAuthTokenCredential;
use PayPal\Rest\ApiContext;
use Illuminate\Support\Facades\DB;
use URL;
use App\Services\PaymentService;
use App\Models\Trip;
use \Auth;
use Illuminate\Http\Response;

class PaymentController extends Controller
{
    private $_api_context;
    private $paymentService;

    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(PaymentService $paymentService)
    {
        $this->paymentService = $paymentService;
        /** PayPal api context **/
        $this->_api_context = new ApiContext(new OAuthTokenCredential(
            config('paypal.client_id'),
            config('paypal.secret')
        ));
        $this->_api_context->setConfig(config('paypal.settings'));
    }



    /**

     * @param  $trip
     * @param Request $request
     * @return void
     */
    public function payWithpaypal($trip, Request $request)
    {
        $trip = Trip::findOrFail($trip);
        $pivot = $trip->customers()->where('customer_id', Auth::user()->customer->id)->first();
        $tripDate = strtotime($trip->due_date)>strtotime(date('y-m-d'));
        if (empty($pivot)) {
            return $this->errorResponse('Customer is not on the trip list', Response::HTTP_NOT_FOUND);
        }
        if ($pivot->pivot->paid&&$tripdate) {
            return $this->errorResponse('Customer already paid or didnt pay on time', Response::HTTP_BAD_REQUEST);
        }
        return redirect($this->paymentService->preparePayment($trip, $this->_api_context)['url']);
    }



    /**
     *
     * @return void
     */
    public function getPaymentStatus(Request $request)
    {
        try {
            $this->paymentService->getPaymentStatus($request);
            return $this->successResponse('Payment Successful', Response::HTTP_ACCEPTED);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('System Error', Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
