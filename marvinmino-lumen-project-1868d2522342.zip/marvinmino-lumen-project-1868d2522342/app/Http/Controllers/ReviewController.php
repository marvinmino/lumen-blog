<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Http\Requests\ReviewStoreRequest;
use App\Models\Customer;
use App\Repositories\ReviewRepository;
use App\Models\Trip;
use App\Models\Review;
use \Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Http\Response;
use App\Jobs\CommercialEmailJob;
use App\Http\Resources\ReviewResource;

class ReviewController extends Controller
{
    private ReviewRepository $reviewRepository;

    /**
     *
     * @param ReviewRepository $reviewRepository
     */
    public function __construct(ReviewRepository $reviewRepository)
    {
        $this->reviewRepository = $reviewRepository;
    }

    /**
     *
     * @param $trip
     * @param ReviewStoreRequest $request
     * @return void
     */
    public function store($trip, ReviewStoreRequest $request)
    {
        try {
            $customer = $this->reviewRepository->getCustomer($trip);
            if ($customer->pivot->paid) {
                $review = $this->reviewRepository->save($request->all(), $trip);
                return new ReviewResource($review);
            }
            return $this->errorResponse("Bad request", Response::HTTP_BAD_REQUEST);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('System Error', Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     *
     * @param $review
     * @param Request $request
     * @return void
     */
    public function destroy($review, Request $request)
    {
        if (!Gate::allows('owns-review', $review)) {
            return $this->errorResponse('Bad request', Response::HTTP_BAD_REQUEST);
        }

        try {
            $this->reviewRepository->delete($review);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('Review not Found', Response::HTTP_NOT_FOUND);
        }

        return $this->successResponse('Success', Response::HTTP_NO_CONTENT);
    }

    /**
     *
     * @param ReviewStoreRequest $request
     * @return void
     */
    public function update(ReviewStoreRequest $request)
    {
        if (Gate::allows('owns-review', $review)) {
            return $this->errorResponse('Bad request', Response::HTTP_BAD_REQUEST);
        }
        
        try {
            $this->reviewRepository->update($request->all(), $request->reviewId);
            return $this->successResponse('Review updated', Response::HTTP_ACCEPTED);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('Review not Found', Response::HTTP_NOT_FOUND);
        }
    }

    /**
     *
     * @param  $trip
     * @return void
     */
    public function index($trip)
    {
        try {
            $reviews = Trip::findOrFail($trip)->reviews->paginate(10);
            return ReviewResource::collection($reviews);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('Not found', Response::HTTP_NOT_FOUND);
        }
    }
}
