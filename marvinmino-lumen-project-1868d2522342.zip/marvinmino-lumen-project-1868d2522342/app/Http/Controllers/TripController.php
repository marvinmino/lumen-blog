<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests\TripStoreRequest;
use App\Http\Requests\TripFilterRequest;
use App\Repositories\TripRepository;
use App\Models\User;
use App\Models\Agency;
use App\Models\Customer;
use App\Models\Trip;
use Illuminate\Support\Facades\Gate;
use \Auth;
use App\Http\Resources\TripResource;
use Illuminate\Http\Response;

class TripController extends Controller
{
    /**
     *@var TripRepository
     */

    private TripRepository $tripRepository;


    /**
     *
     * @param TripRepository $tripRepository
     */
    public function __construct(TripRepository $tripRepository)
    {
        $this->tripRepository = $tripRepository;
    }


    /**
     *
     * @param Request $request
     * @return void
     */
    public function store(TripStoreRequest $request)
    {
        try {
            $data = $this->tripRepository->save($request->all());
            return new TripResource($data);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('System Error', Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     *
     * @param  $trip
     * @param Request $request
     * @return void
     */
    public function show($trip, Request $request)
    {
        try {
            $trip = Trip::findOrFail($trip);
            return new TripResource($trip);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('Trip not found', Response::HTTP_NOT_FOUND);
        }
    }



    /**
     *
     * @param  $trip
     * @param Request $request
     * @return void
     */
    public function destroy($trip, Request $request)
    {
        // if (!Gate::allows('owns-trip', $trip)) {
        //     return $this->errorResponse('Not found', Response::HTTP_NOT_FOUND);
        // }
        try {
            $this->tripRepository->delete($trip);
            return $this->successResponse('Trip Deleted', Response::HTTP_NO_CONTENT);
        } catch (App\Exceptions\TripNotFoundException $e) {
            \Log::error($e);
        }
    }



    /**
     *
     * @param  $trip
     * @param Request $request
     * @return void
     */
    public function edit($trip, TripStoreRequest $request)
    {
        if (!Gate::allows('owns-trip', $trip)) {
            return $this->errorResponse('Not found', Response::HTTP_NOT_FOUND);
        }
        try {
            $this->tripRepository->update($request->all(), $trip);
            return $this->successResponse('Trip updated', Response::HTTP_ACCEPTED);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('System Error', Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     *
     * @param TripFilterRequest $request
     * @return void
     */
    public function index(TripFilterRequest $request)
    {
        try {
            $data = $this->tripRepository->index($request);
            return $this->successResponse($data, Response::HTTP_OK);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('System Error', Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
