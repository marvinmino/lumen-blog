<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\UserStoreRequest;
use App\Http\Requests\UserEmailRequest;
use App\Http\Requests\UserUpdateRequest;
use App\Models\User;
use App\Models\Agency;
use App\Services\MailService;
use Illuminate\Support\Facades\Mail;
use App\Mail\VerifyMailable;
use App\Mail\ResetMailable;
use App\Models\Customer;
use \Auth;
use Illuminate\Http\Response;
use App\Repositories\UserRepository;
use App\Http\Resources\UserResource;
use App\Http\Resources\UserAuthResource;
use Illuminate\Support\Facades\Hash;
use App\Events\VerificationEvent;

class UsersController extends Controller
{
    /**
     *
     * @var $userRepository
     */
 
    protected $userRepository;
    private MailService $mailService;

    /**
     *
     * @param UserRepository $userRepository
     * @param MailService $mailService
     */
    public function __construct(UserRepository $userRepository, MailService $mailService)
    {
        $this->userRepository = $userRepository;
        $this->mailService = $mailService;
    }

    /**
     *
     * @param Request $request
     * @return void
     */
    public function reset(UserResetRequest $request)
    {
        try {
            $this->userRepository->reset($request['token'], $request['password']);
            return $this->successResponse('success', Response::HTTP_ACCEPTED);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('User not Found', Response::HTTP_NOT_FOUND);
        }
    }
    
    /**
     *
     * @param Request $request
     * @return void
     */
    public function store(UserStoreRequest $request)
    {
        try {
            $user = $this->userRepository->save($request->all());
            $user['access_token'] = $user->createToken('MyApp')->accessToken;
            event(new VerificationEvent($user));
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('System error', Response::HTTP_INTERNAL_SERVER_ERROR);
        }
        return new UserAuthResource($user);
    }


    /**
     *
     * @param  $user
     * @param Request $request
     * @return void
     */
    public function show($user, Request $request)
    {
        try {
            $user = User::findOrFail($user);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('User not Found', Response::HTTP_NOT_FOUND);
        }
        return new UserResource($user);
    }

    /**
     *
     * @param  $token
     * @param  $id
     * @param Request $request
     * @return void
     */
    public function verify($token, $id, Request $request)
    {
        try {
            $this->userRepository->verify($id, $token);
            return $this->successResponse('Account verified', Response::HTTP_ACCEPTED);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('Error', Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     *
     * @param Request $request
     * @return void
     */
    public function logout(Request $request)
    {
        $token = Auth::user()->token();
        $token->revoke();
        return $this->successResponse('', Response::HTTP_ACCEPTED);
    }

    /**
     *
     * @param  $user
     * @param Request $request
     * @return void
     */
    public function destroy($user)
    {
        try {
            $this->userRepository->delete($user);
            return $this->successResponse('', Response::HTTP_NO_CONTENT);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('User not Found', Response::HTTP_NOT_FOUND);
        }
    }

    /**
     *
     * @param  $user
     * @param Request $request
     * @return void
     */
    public function update($user, UserUpdateRequest $request)
    {
        try {
            $user = $this->userRepository->update(['password'=>Hash::make($request->password),'phonenr'=>$request->phonenr], $user);
            return $this->successResponse('User updated', Response::HTTP_ACCEPTED);
        } catch (\Exception $e) {
            \Log::error($e);
            return $this->errorResponse('System error', Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     *
     * @return void
     */
    public function verifyEmail()
    {
        $this->mailService->sendEmail(Auth::user()->email, new VerifyMailable([
            'token' => Auth::user()->token,
            'id'    => Auth::user()->id
      ]));
        return $this->successResponse('Success', Response::HTTP_OK);
    }

    /**
     *
     * @param Request $request
     * @return void
     */
    public function resetEmail(UserMailRequest $request)
    {
        $user = User::where('email', $request->input('email'))->firstOrFail();
     
        if (!empty($user)) {
            $this->mailService->sendEmail($request->input('email'), new ResetMailable(['token' => $user->token,'email' =>$request->input('email') ]));
        }

        return $this->successResponse('Verification email sent', Response::HTTP_OK);
    }

    /**
     *
     * @return void
     */
    public function index()
    {
        $users = User::paginate(10);
        return UserResource::collection($users);
    }
}
