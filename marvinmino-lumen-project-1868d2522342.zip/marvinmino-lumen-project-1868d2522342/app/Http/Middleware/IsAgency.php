<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use App\Utilities\Responser;
use Illuminate\Http\Response;

class IsAgency
{
    use Responser;

    /**
     *
     * @param  $request
     * @param Closure $next
     * @return void
     */
    public function handle($request, Closure $next)
    {
        if (!empty(Auth::user()->agency)) {
            return $next($request);
        } else {
            return $this->errorResponse('User not authorized for this action', Response::HTTP_UNAUTHORIZED);
        }
    }
}
