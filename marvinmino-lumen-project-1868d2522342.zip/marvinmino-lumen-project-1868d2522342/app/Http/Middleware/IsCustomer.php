<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use App\Traits\Responser;
use Illuminate\Http\Response;

class IsCustomer
{
    use Responser;

    /**
     * @param  $request
     * @param Closure $next
     * @return void
     */
    public function handle($request, Closure $next)
    {
        if (!empty(Auth::user()->customer)) {
            return $next($request);
        } else {
            return $this->errorResponse('User not authorized for this action', Response::HTTP_UNAUTHORIZED);
        }
    }
}
