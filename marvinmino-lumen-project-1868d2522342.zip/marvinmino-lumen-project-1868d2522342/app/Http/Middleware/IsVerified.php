<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use App\Traits\Responser;
use Illuminate\Http\Response;

class IsVerified
{
    use Responser;

    /**
     * @param  $request
     * @param Closure $next
     * @return void
     */
    public function handle($request, Closure $next)
    {
        if (Auth::user()->verified) {
            return $next($request);
        } else {
            return $this->errorResponse('User not verified', Response::HTTP_UNAUTHORIZED);
        }
    }
}
