<?php

namespace App\Http\Requests;

use Urameshibr\Requests\FormRequest;

class AgencyStoreRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name'    => 'required|max:255|min:1',
            'address' => 'required|min:5|max:255',
            'website' => 'required|min:5|max:255'
        ];
    }
}
