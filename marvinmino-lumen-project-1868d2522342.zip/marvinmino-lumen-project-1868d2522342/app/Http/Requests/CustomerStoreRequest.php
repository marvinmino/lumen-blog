<?php

namespace App\Http\Requests;

use Urameshibr\Requests\FormRequest;

class CustomerStoreRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name'      =>     'required|max:255|min:1',
            'surname'   =>     'required|max:255|min:1',
            'age'       =>     'required|integer|min:13|max:120',
            'gender'    =>     'required|max:255|min:4',
        ];
    }
}
