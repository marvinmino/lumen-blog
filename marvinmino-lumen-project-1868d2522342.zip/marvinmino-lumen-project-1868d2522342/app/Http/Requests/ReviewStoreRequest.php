<?php

namespace App\Http\Requests;

use Urameshibr\Requests\FormRequest;

class ReviewStoreRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'text'   => 'required|max:255|min:32',
            'rating' => 'required|integer|digits_between: 1,2|max:10|min:1',
        ];
    }
}
