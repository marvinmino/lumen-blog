<?php

namespace App\Http\Requests;

use Urameshibr\Requests\FormRequest;

class TripFilterRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'title'      => 'string|max:255',
            'start_date' => 'date|before:end_date',
            'end_date'   => 'date|after:start_date',
            'price'      => 'integer|min:0|max:10000'
        ];
    }
}
