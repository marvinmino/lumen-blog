<?php

namespace App\Http\Requests;

use Urameshibr\Requests\FormRequest;

class TripStoreRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'title'             =>      'required|min:10|max:255',
            'destination'       =>      'required|max:255',
            'price'             =>      'required|integer',
            'start_date'        =>      'required|date|before:end_date',
            'end_date'          =>      'required|date|after:start_date',
            'max_participants'  =>      'required|integer',
            'due_date'          =>      'required|date|before:start_date|before:end_date'
        ];
    }
}
