<?php

namespace App\Http\Requests;

use Urameshibr\Requests\FormRequest;

class UserStoreRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'password'  =>   'min:6|max:32',
            'email'     =>   'required|email|min:3|max:255',
            'phonenr'   =>   'required|max:255',
        ];
    }
}
