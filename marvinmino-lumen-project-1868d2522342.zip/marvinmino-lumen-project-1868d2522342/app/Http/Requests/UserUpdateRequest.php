<?php

namespace App\Http\Requests;

use Urameshibr\Requests\FormRequest;

class UserUpdateRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'password' => 'required|max:255|min:6',
            'phonenr'  => 'required|max:255|min:6',
        ];
    }
}
