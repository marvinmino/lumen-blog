<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class TripResource extends JsonResource
{

/**
    * Transform the resource into an array.
    *
    *  @param  \Illuminate\Http\Request  $request
    *  @return array
    **/
    public function toArray($request)
    {
        return [
            'id'                 =>    $this->id,
            'title'              =>    $this->title,
            'destination'        =>    $this->destination,
            'start_date'         =>    $this->start_date,
            'end_date'           =>    $this->end_date,
            'max_participants'   =>    $this->max_participants,
            'price'              =>    $this->price,
            'due_date'           =>    $this->due_date,
            'agency_id'          =>    $this->agency_id,
        ];
    }
}
