<?php
  
namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Mail\WelcomeEmail;
use App\Models\Trip;
use App\Models\User;
use App\Mail\CommercialMailable;
use Illuminate\Support\Facades\Mail;

class CommercialEmailJob implements ShouldQueue
{
    use InteractsWithQueue, Queueable, SerializesModels;
  
    protected $trip;
    protected $data;
    
    public function __construct($trip, $data)
    {
        $this->trip = $trip;
        $this->data = $data;
    }

    /**
     * Execute the job.
     */
    public function handle()
    {
        $trip = Trip::findOrFail($this->trip);

        foreach ($this->data['customers'] as $data) {
            $mail = $data;
            $customer = User::where('users.email', $mail)->first()->customers;
            if (!empty($customer)) {
                $info = [
                    'destination' => $trip->destination,
                    'trip_id'     => $trip->id,
                    'price'       => $trip->price,
                    'name'        => $customer->name,
                ];
                Mail::to($mail)->send(new CommercialMailable($info));
            }
        }
    }
}
