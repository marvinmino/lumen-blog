<?php

namespace App\Listeners;

use App\Mail\VerifyMailable;
use App\Events\VerificationEvent;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Services\MailService;

class VerificationListener
{
    private MailService $mailService;
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct(MailService $mailService)
    {
        $this->mailService = $mailService;
    }

    /**
     * Handle the event.
     *
     * @param  \App\Events\VerificationEvent  $event
     * @return void
     */
    public function handle(VerificationEvent $event)
    {
        $this->mailService->sendEmail($event->user->email, new VerifyMailable([
            'token' => $event->user->token,
            'id'    => $event->user->id
      ]));
    }
}
