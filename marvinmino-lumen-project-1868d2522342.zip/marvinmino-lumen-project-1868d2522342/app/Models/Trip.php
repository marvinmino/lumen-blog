<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Observers\TripObserver;

class Trip extends Model
{
    use HasFactory,SoftDeletes,TripObserver;



    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'title','destination','start_date','end_date','max_participants','going','price','due_date','agency_id'
    ];



    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [];



    /**
     *
     * @return void
     */
    public function customers()
    {
        return $this->belongsToMany(Customer::class, 'customer_trips')->withPivot('paid');
    }

    /**
     *
     * @return void
     */
    public function reviews()
    {
        return $this->hasMany(Review::class, 'trip_id');
    }

    /**
     *
     * @return void
     */
    public function images()
    {
        return $this->hasMany(Image::class, 'trip_id');
    }



    /**
     * @param  $trip_id
     * @return void
     */
    public function customersCount()
    {
        return $this->customers()->count();
    }
    
    /**
     *
     * @param  $query
     * @param  $agencyId
     * @return void
     */
    public function scopeCreatedBy($query, $agencyId)
    {
        return $query->where('agency_id', $agencyId);
    }

    /**
     *
     * @param  $query
     * @return void
     */
    public function scopeActive($query)
    {
        return $query->where('end_date', '>', date('y-m-d'));
    }

    /**
     *
     * @param  $query
     * @param  $price
     * @return void
     */
    public function scopeCheaperThan($query, $price)
    {
        if (!empty($price)) {
            return $query->where('price', '<', $price);
        }
        return $query;
    }
    
    /**
     *
     * @param  $query
     * @param  $start_date
     * @param  $end_date
     * @return void
     */
    public function scopeDuringTime($query, $start_date, $end_date)
    {
        if (empty($start_date) || empty($end_date)) {
            return $query;
        }
        return $query->where('start_date', '>', $start_date)->where('start_date', '<', $end_date);
    }
}
