<?php
namespace App\Observers;

use App\Models\Trip;
use Log;
use App\Services\MailService;
use App\Mail\TripCancelMailable;
use Illuminate\Support\Facades\Mail;

trait TripObserver
{
    public static function boot()
    {
        parent::boot();

        static::deleted(function ($trip) {
            try {
                $customers = $trip->customers;
                foreach ($customers as $customer) {
                    Mail::to($customer->user->email)->send(new TripCancelMailable([
                        'title'          =>   $trip->title,
                        'destination'    =>   $trip->destination,
                         ]));
                }
            } catch (\Exception $e) {
                \Log::error($e);
            }
        });
    }
}
