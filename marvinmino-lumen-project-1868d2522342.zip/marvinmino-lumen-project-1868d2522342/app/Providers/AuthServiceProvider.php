<?php

namespace App\Providers;

use App\Models\User;
use App\Models\Agency;
use App\Models\Review;
use App\Models\Customer;
use App\Models\Trip;
use App\Models\Image;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Boot the authentication services for the application.
     *
     * @return void
     */
    public function boot()
    {
        // Here you may define how you wish users to be authenticated for your Lumen
        // application. The callback which receives the incoming request instance
        // should return either a User instance or null. You're free to obtain
        // the User instance via an API token or any other method necessary.

        Gate::define('owns-trip', function ($user, $trip) {
            if (!empty($trip = Trip::find($trip))) {
                return Agency::where('user_id', $user->id)->first()->id === $trip->agency_id;
            }
            return false;
        });

        Gate::define('owns-review', function ($user, $review) {
            if (!empty($review = Review::find($review))) {
                return Customer::where('user_id', $user->id)->first()->id === $review->customer_id;
            }
            return false;
        });

        Gate::define('owns-image', function ($user, $image) {
            if (!empty($image = Image::find($image))) {
                return Agency::where('user_id', $user->id)->first()->id === $image->trip->agency->user_id;
            }
            return false;
        });

        $this->app['auth']->viaRequest('api', function ($request) {
            if ($request->input('api_token')) {
                return User::where('api_token', $request->input('api_token'))->first();
            }
        });
    }
}
