<?php

namespace App\Repositories;

use App\Models\Agency;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use \Auth;

class AgencyRepository
{
    /**
     * @var Agency
     */
    protected $agency;

    /**
     * AgencyRepository constructor.
     *
     * @param Agency $agency
     */
    public function __construct(Agency $agency)
    {
        $this->agency = $agency;
    }

    /**
     *
     * @param  $id
     * @return void
     */
    public function delete($id)
    {
        $agency = $this->agency->where('id', $id)->first();
        if (!empty($agency)) {
            $agency->delete();
            $agency->user->delete();
        } else {
            abort(500);
        }
    }

    /**
     * Save agency
     *
     * @param $data
     * @return Agency
     */
    public function save($data)
    {
        $data['user_id'] = Auth::user()->id;
        $agency = $this->agency->create($data);
        return $agency;
    }

    /**
     * Update agency
     *
     * @param $data
     */
    public function update($data, $id)
    {
        $this->agency->where('id', $id)->update($data);
    }

    /**
     * @param  $request
     * @return void
     */
    public function report($request)
    {
        $report = $this->agency
            ->where('id', $request['agency_id'])
            ->with(['trips.customers','trips.reviews','trips' =>
                function ($query) use ($request) {
                    $query->where('created_at', '<', $request['end_date'])
            ->where('created_at', '>', $request['start_date']);
                }])
            ->first();

        $data = [];
        foreach ($report->trips as $trip) {
            $data[] = [
                "trip_id"           =>      $trip->id,
                "trip_title"        =>      $trip->title,
                "average_rating"    =>      $trip->reviews->avg('rating'),
                "total_customers"   =>      $trip->customers->count(),
                "total_amount"      =>      $trip->customers->count('paid') * $trip->price
            ];
        }
        return $data;
    }
}
