<?php

namespace App\Repositories;

use App\Models\Customer;
use App\Models\Trip;
use App\Models\User;
use \Auth;
use Illuminate\Support\Facades\Hash;

class CustomerRepository
{
    /**
     * @var Customer
     */
    protected $customer;

    /**
     *
     * @param Customer $customer
     */
    public function __construct(Customer $customer)
    {
        $this->customer = $customer;
    }



    /**
     *
     * @param $data
     * @return Customer
     */
    public function save($data)
    {
        $data['user_id'] = Auth::user()->id;
        $customer = $this->customer->create($data);
        return $customer;
    }

    /**
     *
     * @param $data
     */
    public function update($data, $id)
    {
        $this->customer->where('id', $id)->update($data);
    }

    /**
     *
     * @param $id
     * @return void
     */
    public function delete($id)
    {
        $customer = $this->customer->where('id', $id)->first();
        if (!empty($customer)) {
            $customer->delete();
            $customer->user->delete();
        } else {
            abort(500);
        }
    }

    /**
     *
     * @param Trip $trip
     * @param $id
     * @return void
     */
    public function participate($trip, $id)
    {
        $trip = Trip::findOrFail($trip);
            
        // check if trip has space for another customer
        $tripMax = $trip->max_participants > $trip->customersCount($trip->id);

        //check if the due date to pay has passed
        $tripDate = strtotime($trip->due_date) > strtotime(date('y-m-d'));
          
        //check if user already participates
        $customerParticipates = $this->participates($id, $trip->id);

        if ($tripMax && $tripDate && $customerParticipates) {
            $trip->customers()->attach($id);
            return;
        }
        abort(500, '');
    }

    /**
     * Check if user participates on given trip
     *
     * @param  $customer_id
     * @param  $trip_id
     * @return void
     */
    public function participates($customer_id, $trip_id)
    {
        $user = Trip::find($trip_id)->customers()->where('customer_id', $customer_id)->where('trip_id', $trip_id)->first();

        if (empty($user)) {
            return true;
        }
        return false;
    }
}
