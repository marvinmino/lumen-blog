<?php

namespace App\Repositories;

use App\Models\Image;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use \Auth;
use Illuminate\Support\Facades\Storage;

class ImageRepository
{
    /**
     * @var image
     */
    protected $image;

    /**
     * @param Image $image
     */
    public function __construct(Image $image)
    {
        $this->image = $image;
    }

    /**
     *
     * @param $trip
     * @param $request
     * @return void
     */
    public function save($trip, $request)
    {
        $imageExist = $this->image->where('name', $request->name)->first();

        if (empty($imageExist)) {

            //get the image extenstion
            $extension = $request->image->extension();

            //store image in public directory in storage
            $request->image->storeAs('/public', $request['name'].".".$extension);

            //get image url
            $url = "app/public/".$request['name'].".".$extension;

            return  $this->image->create([
                   'name' => $request['name'],
                    'url' => $url,
                    'trip_id'=>$trip
                ]);
        }
    }

    /**

     * @param $id
     * @return void
     */
    public function delete($id)
    {
        $image = $this->image->where('id', $id)->first();
        if (!empty($image)) {
            $image->delete();
            unlink(storage_path($image->url));
        } else {
            abort(500);
        }
    }
}
