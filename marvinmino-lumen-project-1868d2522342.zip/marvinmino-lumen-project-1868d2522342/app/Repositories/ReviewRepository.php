<?php

namespace App\Repositories;

use App\Models\Review;
use App\Models\User;
use App\Models\Customer;
use App\Models\Trip;
use Illuminate\Support\Facades\Hash;
use \Auth;

class ReviewRepository
{
    /**
     * @var Review
     */
    protected $review;

    /**
     * reviewRepository constructor.
     *
     * @param Review $review
     */
    public function __construct(Review $review)
    {
        $this->review = $review;
    }

    
    /**
     * Save review
     *
     * @param $data
     * @return Review
     */
    public function save($data, $trip)
    {
        $data['customer_id'] = Auth::user()->customer->id;
        $data['trip_id'] = $trip;
        return $this->review->create($data);
    }

    /**
     *
     * @param  $id
     * @return void
     */
    public function delete($id)
    {
        $review = $this->review->where('id', $id)->first();
        if (!empty($review)) {
            $review->delete();
        } else {
            abort(500);
        }
    }


    /**
     * Update review
     *
     * @param $data
     */
    public function update($data, $id)
    {
        return $this->review->update($data);
    }

    /**
     * Undocumented function
     *
     * @param  $trip
     * @return void
     */
    public function getCustomer($tripId)
    {
        $customerId = Auth::user()->customer->id;
        return Trip::findOrFail($tripId)->customers->where('id', $customerId)->first();
    }
}
