<?php

namespace App\Repositories;

use App\Models\Agency;
use App\Models\Trip;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use \Auth;
use App\Exceptions\TripNotFoundException;

class TripRepository
{
    /**
     * @var Trip
     */
    protected $trip;

    /**
     * TripRepository constructor.
     *
     * @param Trip $trip
     */
    public function __construct(Trip $trip)
    {
        $this->trip = $trip;
    }

    /**
     *
     * @param  $id
     * @return void
     */
    public function delete($id)
    {
        $trip = $this->trip->where('id', $id)->first();
        if (!empty($trip)) {
            $trip->delete();
        } else {
            throw new TripNotFoundException;
        }
    }
    
    /**
     * Save trip
     *
     * @param $data
     * @return trip
     */
    public function save($data)
    {
        $data['agency_id'] = Auth::user()->agency->id;
        return $this->trip->create($data);
    }

    /**
     * Update trip
     *
     * @param $data
     */
    public function update($data, $id)
    {
        return $this->trip->where('id', $id)->update($data);
    }

    /**
     *
     * @param $request
     * @return void
     */
    public function index($request)
    {
        $query = Trip::active()
                    ->cheaperThan($request->input('price'))
                    ->duringTime($request->input('start_date'), $request->input('end_date'))
                    ->where('title', 'like', '%'.$request->input('title').'%');
                    
        $request->whenHas('destination', function () use ($query, $request) {
            $query = $query->where('destination', $request->input('destination'));
        });
                    
        return $query->paginate(10);
    }
}
