<?php

namespace App\Repositories;

use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserRepository
{
    /**
     * @var user
     */
    protected $user;

    /**
     * UserRepository constructor.
     *
     * @param User $user
     */
    public function __construct(User $user)
    {
        $this->user = $user;
    }


    /**
     *
     * @param  $token
     * @param  $password
     * @return void
     */
    public function reset($token, $password)
    {
        return  $this->user->where('token', $token)->update(['password'=>Hash::make($password)]);
    }

    /**
     *
     * @param  $id
     * @param  $token
     * @return void
     */
    public function verify($id, $token)
    {
        return $this->user->where('id', $id)
                ->where('token', $token)
                ->where('verified', false)
                ->update(['verified'=>true]);
    }



    /**
     * Save User
     *
     * @param $data
     * @return user
     */
    public function save($data)
    {
        $data['password'] = Hash::make($data['password']);
        $data['token'] = md5(rand(1, 10) . microtime());
        return $this->user->create($data);
    }

    /**
     * Save User
     *
     * @param $data
     * @return user
     */
    public function delete($id)
    {
        $user = $this->user->where('id', $id)->first();
        if (!empty($user)) {
            $user->delete();
        } else {
            abort(500);
        }
    }

    /**
     * Update User
     *
     * @param $data
     * @return user
     */
    public function update($data, $id)
    {
        return $this->user->where('id', $id)->update($data);
    }
}
