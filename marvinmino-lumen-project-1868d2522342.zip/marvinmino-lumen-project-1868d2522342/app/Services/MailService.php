<?php

namespace App\Services;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\Controller;
use App\Mail\VerifyMailable;
use App\Mail\ResetMailable;
use App\Models\User;
use App\Models\Agency;
use App\Models\Customer;
use \Auth;
use Validator;
use Illuminate\Http\Response;
use App\Utilities\Responser;

class MailService
{
    use Responser;

    /**
     *
     * @param  $user
     * @param  $mailable
     * @return void
     */
    public function sendEmail($user, $mailable)
    {
        Mail::to($user)->send($mailable);
        if (Mail::failures()) {
            return $this->errorResponse('Success', Response::HTTP_INTERNAL_SERVER_ERROR);
        } else {
            return $this->errorResponse('Success', Response::HTTP_OK);
        }
    }
}
