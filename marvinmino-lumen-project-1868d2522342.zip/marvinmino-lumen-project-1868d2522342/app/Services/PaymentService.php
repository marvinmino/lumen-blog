<?php

namespace App\Services;

use Illuminate\Http\Request;
use PayPal\Api\Amount;
use PayPal\Api\Details;
use PayPal\Api\Item;
use App\Traits\Responser;
/** All Paypal Details class **/
use PayPal\Api\ItemList;
use PayPal\Api\Payer;
use PayPal\Api\Payment;
use PayPal\Api\PaymentExecution;
use PayPal\Api\RedirectUrls;
use PayPal\Api\Transaction;
use PayPal\Auth\OAuthTokenCredential;
use PayPal\Rest\ApiContext;
use Illuminate\Support\Facades\DB;
use URL;
use App\Models\Trip;
use \Auth;

class PaymentService
{
    use Responser;
    
    /**
     *
     * @param Trip $trip
     * @param ApiContext $apiContext
     * @return void
     */
    public function preparePayment(Trip $trip, ApiContext $apiContext)
    {
        $payer = new Payer();
        $payer->setPaymentMethod('paypal');

        $item_1 = new Item();

        $item_1->setName($trip->title) /** item name **/
            ->setCurrency('USD')
            ->setQuantity(1)
            ->setPrice($trip->price); /** unit price **/

        $item_list = new ItemList();
        $item_list->setItems(array($item_1));

        $amount = new Amount();
        $amount->setCurrency('USD')
            ->setTotal($trip->price);

        $transaction = new Transaction();
        $transaction->setAmount($amount)
            ->setItemList($item_list)
            ->setDescription('Your transaction description');

        $redirect_urls = new RedirectUrls();
        $redirect_urls->setReturnUrl(URL::to('api/customer/status?trip='.$trip->id.'&customer='.Auth::user()->customer->id)) /** Specify return URL **/
            ->setCancelUrl(URL::to('api/customer/status?trip='.$trip->id.'&customer='.Auth::user()->customer->id));

        $payment = new Payment();
        $payment->setIntent('Sale')
            ->setPayer($payer)
            ->setRedirectUrls($redirect_urls)
            ->setTransactions(array($transaction));
        try {
            $payment->create($apiContext);
        } catch (PayPal\Exception\PayPalConnectionException $ex) {
            echo $ex->getCode(); // Prints the Error Code
            echo $ex->getData(); // Prints the detailed error message1
            die($ex);
        }

        foreach ($payment->getLinks() as $link) {
            if ($link->getRel() == 'approval_url') {
                $redirect_url = $link->getHref();
                break;
            }
        }
        if (isset($redirect_url)) {

            /** redirect to paypal **/
            return ["url"     =>  $redirect_url,
                    "status"  =>  true];
        }
    }
    public function getPaymentStatus($request)
    {
        $trip = Trip::findOrFail($request->input('trip'));
        $paymentId = $request->input('paymentId');
        $payment = Payment::get($paymentId, $this->_api_context);
        $execution = new PaymentExecution();
        $execution->setPayerId($request->input('PayerID'));

        /**Execute the payment **/
        $result = $payment->execute($execution, $this->_api_context);

        if ($result->getState() == 'approved') {
            $trip->customers()
            ->where('customer_id', Auth::user()->customer->id)
            ->where('trip_id', $trip->id)
            ->updateExistingPivot(
                $trip->id,
                ['paid' => true]
            );
        }
    }
}
