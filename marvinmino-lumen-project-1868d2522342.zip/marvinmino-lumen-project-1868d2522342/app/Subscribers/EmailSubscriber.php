<?php

namespace App\Subscribers;

use App\Models\User;
use App\Mail\VerifyMailable;
use App\Services\MailService;

class EmailSubscriber
{
    private MailService $mailService;
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct(MailService $mailService)
    {
        $this->mailService = $mailService;
    }

    public function onUserRegister($event)
    {
        $this->mailService->sendEmail($event->user->email, new VerifyMailable([
            'token' => $event->user->token,
            'id'    => $event->user->id
      ]));
    }
    public function subscribe($events)
    {
        $events->listen(
            'App\Events\VerificationEvent',
            'App\Subscribers\EmailSubscriber@onUserRegister'
        );
    }
}
