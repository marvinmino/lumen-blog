<?php

namespace Database\Factories;

use App\Models\Image;
use App\Models\Trip;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;

class ImageFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Image::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'name'          =>        $this->faker->unique()->name,
            'url'           =>        $this->faker->unique()->url,
            'trip_id'       =>        Trip::factory(),
    ];
    }
}
