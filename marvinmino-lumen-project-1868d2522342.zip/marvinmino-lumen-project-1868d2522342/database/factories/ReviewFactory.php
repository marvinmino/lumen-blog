<?php

namespace Database\Factories;

use App\Models\Review;
use App\Models\Customer;
use App\Models\Trip;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;

class ReviewFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Review::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $customers = Customer::all()->toArray();
        $trips = Trip::all()->toArray();
        
        return [
            'text'            =>        $this->faker->paragraph,
            'rating'          =>        rand(1, 10),
            'trip_id'         =>        $trips[rand(0, count($trips)-1)]['id'],
            'customer_id'     =>        $customers[rand(0, count($customers)-1)]['id'],
    ];
    }
}
