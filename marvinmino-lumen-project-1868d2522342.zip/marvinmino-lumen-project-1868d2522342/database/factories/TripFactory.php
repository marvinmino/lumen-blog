<?php

namespace Database\Factories;

use Carbon\Carbon;
use App\Models\Trip;
use App\Models\Agency;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;

class TripFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Trip::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $startDate = Carbon::now()->subDays(rand(5, 40));
        $endDate = Carbon::now()->addDays(rand(5, 40))->toDateString() ;

        //Get all agencies. If there are none create 10
        $agencies = Agency::all()->toArray();
        if (count($agencies) < 10) {
            $agencies = Agency::factory()->count(10)->create()->toArray();
        }
        
        $agency = $agencies[rand(0, count($agencies)-1)];
        

        return [
            'title'             =>        $this->faker->unique()->country,
            'destination'       =>        $this->faker->city,
            'price'             =>        rand(100, 2000),
            'max_participants'  =>        rand(5, 100),
            'start_date'        =>        $startDate->toDateString(),
            'end_date'          =>        $endDate,
            'due_date'          =>        $startDate->subDays(rand(1, 5))->toDateString() ,
            'agency_id'         =>        $agency['id'],
    ];
    }
}
