<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        if (env('APP_ENV', '') == 'local') {
            $this->call(CustomersTableSeeder::class);
            $this->call(AgenciesTableSeeder::class);
            $this->call(TripsTableSeeder::class);
        }
    }
}
