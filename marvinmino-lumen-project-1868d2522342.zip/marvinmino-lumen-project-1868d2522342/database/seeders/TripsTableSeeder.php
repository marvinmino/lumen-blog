<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Agency;
use App\Models\Trip;
use App\Models\User;
use App\Models\Customer;

class TripsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */

    public function run()
    {
        $customers = Customer::all()->toArray();
        if (count($customers) < 10) {
            $customers = Customer::factory()->count(20)->create()->toArray();
        }
        
        Trip::factory()
            ->count(150)
            ->hasReviews(rand(1, 15))
            ->hasImages(rand(0, 3))
            ->create()
            ->each(function ($trip) use ($customers) {
                for ($i = 0; $i < rand(2, 22); $i++) {
                    $customer = $customers[rand(0, count($customers)-1)];
                    $trip->customers()->attach($customer['id']);
                }
            });
    }
}
