<p>Hello recipient,</p>
<p>This is a sample email. Please do not reply!</p>
<p>
Regards,<br>
Sender.
</p>