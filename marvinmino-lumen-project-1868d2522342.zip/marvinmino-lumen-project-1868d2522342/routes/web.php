<?php

/** @var \Laravel\Lumen\Routing\Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/
$router->get('/', function () {
    $startDate = \Carbon\Carbon::now()->subDays(rand(5, 40));
    return (['start_date'=>$startDate->toDateString(),'due_date'=>$dueDate = $startDate->subDays(rand(1, 5))->toDateString() ]);
});

$router->group(['prefix' => 'api'], function () use ($router) {
    $router->get('agency/report', 'AgencyController@report');
    $router->get('agency/download-report', 'AgencyController@downloadReport');
    //Agency or Admin related routes
    $router->group(['middleware' => ['auth','admin-agency']], function () use ($router) {
        $router->get('trip/index', 'TripController@index');
        $router->get('trip/{trip}/reviews', 'ReviewController@index');
    });

    //Admin related routes
    $router->group(['middleware' => ['auth','admin']], function () use ($router) {
        $router->get('user/index', 'UsersController@index');
        $router->get('agency/index', 'AgencyController@index');
    });

    //User related routes
    $router->group(['prefix'=>'user'], function () use ($router) {
        $router->group(['middleware' => 'auth'], function () use ($router) {
            $router->group(['middleware' => 'verified'], function () use ($router) {
                $router->post('customer', 'CustomerController@store');
                $router->post('agency', 'AgencyController@store');
            });
            $router->get('/logout', 'UsersController@logout');
            $router->get('/verify-mail', 'UsersController@verifyEmail');
            $router->delete('/{user}', 'UsersController@destroy');
            $router->patch('{user}', 'UsersController@update');
            $router->get('{user}', 'UsersController@show');
        });
    });
    
    //Agency related routes
    $router->group(['prefix'=>'agency'], function () use ($router) {
        $router->group(['middleware' => ['auth','agency']], function () use ($router) {
            //Trip related routes
            $router->group(['prefix'=>'trip'], function () use ($router) {
                $router->post('', 'TripController@store');
                $router->delete('/{trip}', 'TripController@destroy');
                $router->put('/{trip}', 'TripController@update');
                $router->post('image/{trip}', 'ImageController@store');
                $router->delete('image/{image}', 'ImageController@destroy');
                $router->get('image/{image}', 'ImageController@show');
                $router->get('index', 'ImageController@index');
                $router->get('/{trip}', 'TripController@show');
            });

            $router->get('/{agency}', 'AgencyController@show');
            $router->post('send-ads/{trip}', 'AgencyController@sendad');
            // $router->delete('/{agency}', 'UsersController@destroy');
            $router->put('/{agency}', 'UsersController@update');
        });
    });
    
    //Customer related routes
    $router->group(['prefix'=>'customer'], function () use ($router) {
        $router->group(['middleware' => 'verified'], function () use ($router) {
            $router->get('status', 'PaymentController@getPaymentStatus');
            $router->get('pay/trip/{trip}', 'PaymentController@payWithpaypal');
        });
        $router->group(['middleware' => ['auth','customer']], function () use ($router) {
            $router->put('', 'CustomerController@update');
            $router->delete('/{customer}', 'CustomerController@destroy');
            $router->get('index', 'CustomerController@index');
            $router->post('participate', 'CustomerController@participate');
            $router->get('/{customer}', 'CustomerController@show');
            $router->post('trip/{trip}/review/', 'ReviewController@store');
            $router->put('trip/review', 'ReviewController@update');
            $router->get('trip/review/{review}', 'ReviewController@show');
            $router->delete('trip/review/{review}', 'ReviewController@destroy');
        });
    });

    $router->post('/register', 'UsersController@store');
    $router->get('/verify/{token}/{id}', 'UsersController@verify');
    $router->post('/reset-mail', 'UsersController@resetEmail');
    $router->patch('/reset', 'UsersController@reset');
});
