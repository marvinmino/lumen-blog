<p>Hello recipient,</p>
<p>This is a sample email. Please do not reply!</p>
<p>
Regards,<br>
Sender.
</p><?php /**PATH /home/marvin-atis/code/Task5Atis/resources/views/my-email.blade.php ENDPATH**/ ?>